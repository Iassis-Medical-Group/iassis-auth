import logging
from datetime import timedelta
from typing import Optional

from fastapi import APIRouter, Cookie, Depends, HTTPException, Request, Response
from fastapi.security import OAuth2PasswordRequestForm
from limiter import limiter
from database import personnel
from settings import settings
from services.auth import (
    TokenClaims,
    authenticate_user, get_current_user, create_token, create_refresh_token,
    decode_refresh_token,
)

auth_router = APIRouter(prefix="/api/auth", tags=["JWT"])
logger = logging.getLogger(__name__)


@auth_router.post("/login")
@limiter.limit("10/minute")
def login(request: Request, response: Response, form: OAuth2PasswordRequestForm = Depends()):
    """
    Authenticate a user and issue JWT access + refresh tokens.

    Args:
        response (Response): FastAPI response object used to set the refresh-token cookie.
        form (OAuth2PasswordRequestForm): Standard OAuth2 form with ``username`` and ``password`` fields.

    Returns:
        dict: {
            "access_token" (str): Short-lived JWT bearer token,
            "type" (str): Always ``"bearer"``,
            "user" (dict): {username, email, roles, first_name, last_name}
        }

    Raises:
        HTTPException 401: If credentials are invalid or the user does not exist.
    """
    user = authenticate_user(form.username, form.password)
    if not user:
        logger.warning("Failed login attempt for username '%s'", form.username)
        raise HTTPException(status_code=401, detail="Λάθος στοιχεία χρήστη")

    claims        = TokenClaims(sub=form.username, email=user["auth"]["email"], roles=user["auth"].get("roles", []))
    access_token  = create_token(claims)
    refresh_token = create_refresh_token(form.username)

    response.set_cookie(
        key      = "refresh_token",
        value    = refresh_token,
        httponly = True,
        secure   = settings.SECURE_COOKIE,
        samesite = "Strict",
        max_age  = timedelta(minutes=settings.TOKEN_REFRESH_MINUTES),
        path     = "/api/auth/refresh",
    )
    logger.info("Login successful: user='%s' roles='%s'", form.username, user["auth"].get("roles", []))
    return {
        "access_token": access_token,
        "type": "bearer",
        "user": {
            "username":   user["auth"]["username"],
            "email":      user["auth"]["email"],
            "roles":      user["auth"].get("roles", []),
            "first_name": user["profile"]["first_name"],
            "last_name":  user["profile"]["last_name"],
        },
    }


@auth_router.post("/refresh")
def refresh(refresh_token: Optional[str] = Cookie(None)):
    """
    Issue a new access token using the refresh token stored in the HTTP-only cookie.

    Args:
        refresh_token (str | None): Refresh JWT read from the ``refresh_token`` HTTP-only cookie.

    Returns:
        dict: {"access_token" (str): New short-lived bearer token, "type": "bearer"}

    Raises:
        HTTPException 401: If the cookie is missing, the token is invalid, or the user is inactive.
    """
    if not refresh_token:
        raise HTTPException(status_code=401, detail="No refresh token")

    username = decode_refresh_token(refresh_token)

    user = personnel.find_one({"auth.username": username, "auth.is_active": True})
    if not user:
        raise HTTPException(status_code=401, detail="User not found or inactive")

    claims = TokenClaims(sub=username, email=user["auth"]["email"], roles=user["auth"].get("roles", []))
    return {"access_token": create_token(claims), "type": "bearer"}


@auth_router.post("/logout")
def logout(response: Response):
    """
    Clear the refresh-token cookie to log out the current user.

    Args:
        response (Response): FastAPI response object used to delete the cookie.

    Returns:
        dict: {"ok": True}
    """
    response.delete_cookie(
        key      = "refresh_token",
        httponly = True,
        secure   = settings.SECURE_COOKIE,
        samesite = "Strict",
        path     = "/api/auth/refresh",
    )
    return {"ok": True}


@auth_router.get("/me")
def me(current=Depends(get_current_user)):
    """
    Return the profile of the currently authenticated user.

    Args:
        current (dict): Injected by ``get_current_user`` dependency from the bearer token.

    Returns:
        dict: {username, email, roles (list[str]), first_name, last_name}

    Raises:
        HTTPException 401: If the token is invalid or the user no longer exists in the database.
    """
    user = personnel.find_one(
        {"auth.username": current["auth"]["username"]},
        {"auth.password_hash": 0},
    )
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return {
        "username":   user["auth"]["username"],
        "email":      user["auth"]["email"],
        "roles":      user["auth"].get("roles", []),
        "first_name": user["profile"]["first_name"],
        "last_name":  user["profile"]["last_name"],
    }
