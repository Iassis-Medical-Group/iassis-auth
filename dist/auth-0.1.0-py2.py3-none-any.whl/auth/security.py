from datetime import datetime, timezone, timedelta

from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
import jwt
from jwt.exceptions import PyJWTError
from passlib.context import CryptContext
from pydantic import BaseModel

from settings import settings
from database import personnel


class TokenClaims(BaseModel):
    sub:   str
    email: str
    roles: list[str]

pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2  = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

# Precomputed dummy hash used when the username doesn't exist, so bcrypt always
# runs and response time is constant — prevents timing-based username enumeration.
_DUMMY_HASH: str = pwd_ctx.hash("__dummy__")


def get_current_user(token: str = Depends(oauth2)):
    """
    FastAPI dependency that decodes the bearer token and returns a lightweight user dict.

    Reads claims directly from the JWT — no database round-trip. Used as a dependency
    in endpoints that require authentication but not a specific role.

    Args:
        token (str): Bearer JWT extracted from the ``Authorization`` header by ``OAuth2PasswordBearer``.

    Returns:
        dict: {"auth": {"username", "email", "roles" (list[str]), "is_active": True}}

    Raises:
        HTTPException 401: If the token is missing, expired, or cannot be decoded.
    """
    try:
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.ALGORITHM])
        if payload.get("type") != "access":
            raise HTTPException(status_code=401, detail="Invalid token type")
        username = payload.get("sub")
        if not username:
            raise HTTPException(status_code=401, detail="Invalid token")
        return {
            "auth": {
                "username": username,
                "email":    payload.get("email", ""),
                "roles":    payload.get("roles", []),
                "is_active": True,
            },
        }
    except PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid token")


def verify_password(plain, hashed):
    """
    Verify a plaintext password against a bcrypt hash.

    Args:
        plain (str): The plaintext password supplied by the user.
        hashed (str): The stored bcrypt hash to verify against.

    Returns:
        bool: ``True`` if the password matches, ``False`` otherwise.
    """
    return pwd_ctx.verify(plain, hashed)


def authenticate_user(username: str, password: str) -> dict | None:
    """Return the user doc if credentials are valid, None otherwise.
    Always runs bcrypt regardless of whether the username exists, so response
    time is constant and attackers cannot enumerate valid usernames via timing."""
    user = personnel.find_one({"auth.username": username, "auth.is_active": True})
    stored_hash = user["auth"]["password_hash"] if user else _DUMMY_HASH
    if not verify_password(password, stored_hash) or not user:
        return None
    return user


def hash_password(plain):
    """
    Hash a plaintext password with bcrypt.

    Args:
        plain (str): The plaintext password to hash.

    Returns:
        str: A bcrypt hash string suitable for storage in MongoDB.
    """
    return pwd_ctx.hash(plain)


def create_token(claims: TokenClaims) -> str:
    """
    Create a short-lived JWT access token.

    Args:
        claims (TokenClaims): Token payload containing ``sub`` (username), ``email``, and ``roles``.

    Returns:
        str: Signed JWT access token string, valid for ``settings.TOKEN_EXPIRE`` minutes.
    """
    payload = claims.model_dump()
    payload["exp"]  = datetime.now(timezone.utc) + timedelta(minutes=settings.TOKEN_EXPIRE)
    payload["type"] = "access"
    return jwt.encode(payload, settings.JWT_SECRET, algorithm=settings.ALGORITHM)


def create_refresh_token(username: str) -> str:
    """
    Create a long-lived JWT refresh token.

    The token carries only ``sub`` (username) and ``type: "refresh"``. It is
    stored in an HTTP-only cookie and never returned in the response body.

    Args:
        username (str): The authenticated user's username (used as the ``sub`` claim).

    Returns:
        str: Signed JWT refresh token string, valid for ``settings.TOKEN_REFRESH_MINUTES`` minutes.
    """
    payload = {
        "sub":  username,
        "exp":  datetime.now(timezone.utc) + timedelta(minutes=settings.TOKEN_REFRESH_MINUTES),
        "type": "refresh",
    }
    return jwt.encode(payload, settings.JWT_SECRET, algorithm=settings.ALGORITHM)


def decode_refresh_token(token: str) -> str:
    """Decode a refresh token and return the username. Raises HTTPException on any failure."""
    try:
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.ALGORITHM])
        if payload.get("type") != "refresh":
            raise HTTPException(status_code=401, detail="Invalid token type")
        username = payload.get("sub")
        if not username:
            raise HTTPException(status_code=401, detail="Invalid token")
        return username
    except PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid refresh token")


def require_role(*allowed):
    """
    FastAPI dependency factory that restricts access to one or more roles.

    Args:
        *allowed (str): One or more role names that are permitted (e.g. ``"admin"``, ``"reception"``).

    Returns:
        Callable: A FastAPI dependency that returns the current user dict if authorised.

    Raises:
        HTTPException 403: If none of the user's roles appear in ``allowed``.
    """
    def dep(current=Depends(get_current_user)):
        user_roles = current["auth"].get("roles", [])
        if not any(r in allowed for r in user_roles):
            raise HTTPException(status_code=403, detail="Δεν έχετε δικαίωμα για αυτήν την ενέργεια")
        return current
    return dep
